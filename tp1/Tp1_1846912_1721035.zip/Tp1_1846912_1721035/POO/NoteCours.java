package POO;

public class NoteCours {
	public String sigle;
	public String titre;
	public int note;
	
}

