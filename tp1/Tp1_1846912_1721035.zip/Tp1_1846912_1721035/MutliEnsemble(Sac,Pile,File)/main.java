package MultiEnsemble;
/*
 * Le package MultiEnsemble a �t� r�alis� avec l'aide du site
 * https://algs4.cs.princeton.edu/13stacks/. La partie 3 de se TD
 * semble reposer en grande partie sur les fichiers de ce site.
 * 
 * Nous avons modifi� les fichiers sources pour satisfaire � ce TD.
 * 
 */

public final class main{
	public static void main(String[] args) {
		System.out.println("Des tests sont effectuer sur chacun des fichier Sac.java, Pile.java et File.java. "
				+ System.lineSeparator()+"Vous n'avez qu'a run chacun de ces fichiers comme Application Java pour affichier la sortie."
				+System.lineSeparator()+ "Ce TD a �t� r�alis� par Paul Clas et Mazigh Ouanes.");
	}
}